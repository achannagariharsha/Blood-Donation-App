import React from 'react'

const Error = () => {
  return (
    <section className='bg-container'>
      <h1>Error404 - Not Found</h1>
    </section>
  )
}

export default Error